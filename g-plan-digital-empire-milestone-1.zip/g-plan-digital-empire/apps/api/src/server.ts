import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import { PrismaClient } from "@prisma/client";
import { z } from "zod";

const app = express();
const prisma = new PrismaClient();
const port = Number(process.env.PORT ?? 4000);
const allowedOrigin = process.env.CORS_ORIGIN ?? "http://localhost:3000";
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: allowedOrigin.split(",").map((v) => v.trim()), credentials: true }));
app.use(express.json({ limit: "1mb" }));

app.get("/api/v1/health", (_req, res) => {
  res.json({ status: "ok", service: "g-plan-api", version: "0.1.0", timestamp: new Date().toISOString() });
});

app.get("/api/v1/ready", async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ status: "ready", checks: { database: "connected" } });
  } catch {
    res.status(503).json({ status: "not_ready", checks: { database: "unavailable" } });
  }
});

app.get("/api/v1/services", (_req, res) => {
  res.json({ data: [
    { slug: "ai-marketing", name: "AI Marketing", description: "Strategy, content and campaign support." },
    { slug: "creative-studio", name: "Creative Studio", description: "Brand design, graphics and video production." },
    { slug: "automation", name: "Business Automation", description: "Practical workflow and customer support automation." },
    { slug: "business-intelligence", name: "Business Intelligence", description: "Analytics, reporting and growth insights." }
  ], source: "application_catalog" });
});

const enquirySchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(254),
  company: z.string().trim().max(120).optional().or(z.literal("")),
  service: z.string().trim().min(2).max(80),
  message: z.string().trim().min(10).max(3000)
});
app.post("/api/v1/enquiries", async (req, res) => {
  const parsed = enquirySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "invalid_enquiry", details: parsed.error.flatten() });
  try {
    const enquiry = await prisma.enquiry.create({ data: parsed.data });
    return res.status(201).json({ data: { id: enquiry.id, status: enquiry.status, createdAt: enquiry.createdAt }, message: "Enquiry received." });
  } catch {
    return res.status(500).json({ error: "enquiry_creation_failed", message: "The enquiry could not be saved. Please try again." });
  }
});

app.use((_req, res) => res.status(404).json({ error: "not_found" }));
const server = app.listen(port, () => console.log(`G-PLAN API listening on :${port}`));

async function shutdown() {
  server.close();
  await prisma.$disconnect();
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
